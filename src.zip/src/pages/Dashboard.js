import React from 'react';

const Dashboard = () => {
  return (
    <div className='col'>
       <h1 className='col mt-5'>Welcome To Our company</h1>
       </div>
  );
};



export {Dashboard};
